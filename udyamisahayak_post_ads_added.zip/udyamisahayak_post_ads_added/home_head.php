<meta name="author" content="">
<meta name="description" content="">
<meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<!-- Favicon -->
<link rel="shortcut icon" href="images/mgiri.png">
<!-- Style CSS -->
<link rel="stylesheet" href="css/stylesheet.css">
<link rel="stylesheet" href="css/mmenu.css">
<link rel="stylesheet" href="css/style.css" id="colors">
<!-- Google Font -->
<link href="https://fonts.googleapis.com/css?family=Nunito:300,400,600,700,800&amp;display=swap&amp;subset=latin-ext,vietnamese" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,500,600,700,800" rel="stylesheet" type="text/css">
<!-- ****NEW**-->
<link type="text/css" rel="stylesheet" href="css/im-homepage-v39.min.css">
<!--chrome-->
<link href="css/styles.css" rel="stylesheet" type="text/css">
<link href="css/styles2.css" rel="stylesheet" type="text/css">
<link href="css/styles3.css" rel="stylesheet" type="text/css">
<link href="css/grid.css" rel="stylesheet" type="text/css">
<link href="css/reset.css" rel="stylesheet" type="text/css">
<link href="css/stylenew.css" rel="stylesheet" type="text/css">
<link href="css/thumbs.css" rel="stylesheet" type="text/css">

<link rel="icon" href="images/favicon.ico">
<link rel="shortcut icon" href="images/favicon.ico" />
<link rel="stylesheet" href="css/form.css">
<link rel="stylesheet" href="css/thumbs.css">
<link rel="stylesheet" href="css/slider.css">
<link rel="stylesheet" href="css/style.css">