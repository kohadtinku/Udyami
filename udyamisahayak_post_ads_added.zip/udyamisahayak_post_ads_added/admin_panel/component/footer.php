<div class="col-md-12">
  <div class="footer_copyright_part">All copyrights reserved © 2023 - Design & Development by Royals WebTech Pvt. Ltd.</div>
</div>