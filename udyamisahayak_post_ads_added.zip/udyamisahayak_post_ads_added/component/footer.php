<div class="col-md-12">
  <div class="footer_copyright_part" style="width: 50% !important; display:inline!important;float:left; font-size: 95%;">All copyrights reserved © 2023 - Design & Development by Royals WebTech Pvt. Ltd.</div>


  <div class="footer_copyright_part" style="width: 50% !important; display:inline!important;float:right">
    <!-- Histats.com  (div with counter) -->
    <div id="histats_counter"></div>
    <!-- Histats.com  START  (aync)-->
    <script type="text/javascript">
      var _Hasync = _Hasync || [];
      _Hasync.push(['Histats.start', '1,4796525,4,2045,280,25,00011001']);
      _Hasync.push(['Histats.fasi', '1']);
      _Hasync.push(['Histats.track_hits', '']);
      (function() {
        var hs = document.createElement('script');
        hs.type = 'text/javascript';
        hs.async = true;
        hs.src = ('//s10.histats.com/js15_as.js');
        (document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(hs);
      })();
    </script>
    <noscript><a href="/" target="_blank"><img src="//sstatic1.histats.com/0.gif?4796525&101" alt="counter free hit invisible" border="0"></a></noscript>
    <!-- Histats.com  END  -->
  </div>



</div>