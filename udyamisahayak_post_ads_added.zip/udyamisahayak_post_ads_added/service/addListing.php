<?php 

echo"hello";
?>